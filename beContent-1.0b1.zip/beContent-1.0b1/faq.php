<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";
require "include/content.inc.php";

$main = new Skin("dipartimento");

$content = new Content($faqEntity, $faqtypeEntity);

$content->setStyle(HIERARCHICAL);
$content->setOrderFields("category", "position");
$content->setPresentation("faqtype_name", "faq_id", "faq_question", "faq_creation", "faq_answer");
$content->setParameter("doc_public", "*");

$main->setContent("body", $content->get());
$main->close();  

?>