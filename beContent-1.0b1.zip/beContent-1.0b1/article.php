<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";
require "include/content.inc.php";

$main = new Skin("viveremeglio");
$body = new Template("skins/viveremeglio/dtml/articles_single.html");



$article = new Content($articleEntity, $categoryEntity);
$article->propagate("articles_category", "categories_id");
#$article->propagate("categories_class", "categories_class");
$article->applyItem($body, $_REQUEST['articles_id']);
$article->applyItem($main, $_REQUEST['articles_id'], "active");


$cat = new Content($categoryEntity);
$cat->copy("categories.name", "categories_url");
$cat->setOrderFields("position");
$cat->setTrigger("selected","class=\"selected\"");
$cat->applyalfonso	($main);



$ipiuletti = new Content($articleEntity);
$ipiuletti->copy("articles.title", "articles_url");
$ipiuletti->setOrderFields("stats DESC");
$ipiuletti->setLimit(7);
$ipiuletti->apply($main, "ipiuletti");

$main->setContent("body", $body->get());
$main->close();

$oid = mysql_query("UPDATE articles SET stats = stats +1 WHERE id = {$_REQUEST['articles_id']}");



?>