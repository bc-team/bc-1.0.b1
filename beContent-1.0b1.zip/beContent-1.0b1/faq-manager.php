<?php

session_start();


require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$faqEntity);

$form->addSection("FAQ Management");


$form->addText("question_it", "Name (it)", 50);
$form->addText("question_en", "Name (en)", 50);
$form->addSelectFromReference2($faqtypeEntity, "category", "Category", MANDATORY);
$form->addEditor("answer_it", "Body (it)", 7, 70);
$form->addEditor("answer_en", "Body (en)", 7, 70);
$form->addCheck("Public", ":public:*:CHECKED");
$form->addHierarchicalPosition("position", "Position", "question_it", "category");

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}


$main->close();

?> 