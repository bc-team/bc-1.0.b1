<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";
require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$eventEntity);

$form->addSection("Event Management");

$form->addText("acronym", "Acronym", 20, MANDATORY);
$form->addText("name", "Name", 80, MANDATORY);
$form->addText("venue", "Venue", 40, MANDATORY);
$form->addText("country", "Country", 40, MANDATORY);
$form->addEditor("body", "Text", 6, 50);
$form->addText("link", "Link", 80, MANDATORY);

$form->addDate("date_begin", "Begin", MANDATORY);
$form->addDate("date_end", "End", MANDATORY);




if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}

$main->close();

?> 