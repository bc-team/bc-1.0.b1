<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$faqtypeEntity);

/*

$faqtypeEntity->addField("name_it", VARCHAR, 40);
$faqtypeEntity->addField("name_en", VARCHAR, 40);
$faqtypeEntity->addField("body_it", TEXT);
$faqtypeEntity->addField("body_en", TEXT);
$faqtypeEntity->addField("position", POSITION);
$faqtypeEntity->addReference($faqtypeEntity, "parent_id");

*/

$form->addSection("Faq Category Management");

$form->addText("name_it", "Name (it)", 40, MANDATORY);
$form->addText("name_en", "Name (en)", 40, MANDATORY);
$form->addEditor("body_it", "Body (it)", 7, 70);
$form->addEditor("body_en", "Body (en)", 7, 70);
$form->addSelectFromReference2($faqtypeEntity, "parent_id", "Parent");
$form->addHierarchicalPosition("position", "Position", "name_it", "parent_id");

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}


$main->close();

?> 