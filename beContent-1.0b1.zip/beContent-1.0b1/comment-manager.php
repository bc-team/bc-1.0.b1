<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

/* LOCAL START */

/* LOCAL END */

$main = new Skin(); 

$form = new Form("dataEntry",$commentEntity);
$form->addSection("Pubblica Commento");
$form->addTextArea("body", "Commento", 10, 70);
$form->addCheck("Pubblica", ":active:*:CHECKED"); 


Class myPager extends becontentPager {
	
	function myPager() {
		beContentPager::beContentPager(8);
	}
	
	function display($k,$v) {
		switch($k) {
			case "creation": 
				return aux::xmlchars(aux::formatDate($v, SHORT_LETTERS), MODE3);
				break;
				
			case "body": 
				#return aux::xmlchars(aux::subtext(addslashes($v), 150), MODE3);
				return aux::xmlchars(aux::subtext($v, 150), MODE3);
				break;
			case "new":
				
				if ($v == '*') {
					return "new";
				} else {
					return "not_new";
				}
				
				break;
		
			default:
				return beContentPager::display($k,$v);
				break;
		
		}
				
		return $v;
	}	
}

$pager = &new myPager();
$pager->setQuery("
	SELECT comments.id,
		   comments.username,
		   comments.creation,
		   comments.body,
		   comments.active,
		   comments.new,
		   news.title
      FROM comments
 LEFT JOIN news
        ON news.id = comments.itemid
     WHERE entityname = 'news'
  ORDER BY new DESC, creation DESC");

$pager->setFilter("(comments.username LIKE '%[search]%' OR comments.body LIKE '%[search]%' OR news.title LIKE '%[search]%')");

$pager->setTemplate("dtml/report-comments.html");
$form->setPager($pager); 


if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}

switch($_REQUEST['action']) {
	case "add":
		$main->setContent("body",$form->addItem());
		break;
	case "edit":
		$main->setContent("body",$form->editItem());
		break;
}

$main->close();

?> 