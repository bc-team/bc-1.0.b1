<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";
require "include/content.inc.php";

$main = new Skin("dipartimento");


$events = new Content($eventEntity, $usersEntity);
$events->setOrderFields("date_begin DESC");

$main->setContent("body", $events->getPager());
$main->close();  


?>