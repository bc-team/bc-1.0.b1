<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$articleEntity);

$form->addSection("Article Management");

$form->addText("title", "Title", 60);
$form->addSelectFromReference2($categoryEntity, "category", "Categoria", MANDATORY);
$form->addText("subtitle", "Subtitle", 80);
$form->addEditor("body", "Content",20,50); 
$form->addFile("foto", "Foto");

$form->addSection("SEO Specific", "The following are important to get the page correctly indexed by the search engines.");

$form->addText("pagetitle", "Page Title", 60);
$form->addText("keywords", "Keywords", 80);
$form->addTextarea("description", "Description", 4, 77);
$form->addTextarea("links", "Links", 6, 77);

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}

$main->close();

?> 