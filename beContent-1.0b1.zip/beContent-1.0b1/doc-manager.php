<?php

session_start();


require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$docEntity);

$form->addSection("Document Management");
/*
$docEntity->addField("name_it", VARCHAR, 100);
$docEntity->addField("name_en", VARCHAR, 100);
$docEntity->addField("document", FILE);
$docEntity->addReference($doctypeEntity, "category");
$docEntity->addField("body_it", TEXT);
$docEntity->addField("body_en", TEXT);
$docEntity->addField("public", VARCHAR, 1);
$docEntity->addField("position", POSITION);
*/

$form->addText("name_it", "Name (it)", 50);
$form->addText("name_en", "Name (en)", 50);
$form->addFile("document", "Document");
$form->addSelectFromReference2($doctypeEntity, "category", "Category", MANDATORY);
$form->addEditor("body_it", "Body (it)", 7, 70);
$form->addEditor("body_en", "Body (en)", 7, 70);
$form->addCheck("Public", ":public:*:CHECKED");
$form->addHierarchicalPosition("position", "Position", "name_it", "category");

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}


$main->close();

?> 