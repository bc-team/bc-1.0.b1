<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$categoryEntity);

/* 

$categoryEntity->addField("name", VARCHAR, 255);
$categoryEntity->addField("position", POSITION);
$categoryEntity->addReference($categoryEntity, "parent_id");

*/

$form->addSection("Category Management");

$form->addText("name", "Nome", 70, MANDATORY);
$form->addText("class", "CSS Class", 50);
$form->addSelectFromReference2($categoryEntity, "parent_id", "Parent");
$form->addHierarchicalPosition("position", "Order", "name", "parent_id");

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}


$main->close();

?> 