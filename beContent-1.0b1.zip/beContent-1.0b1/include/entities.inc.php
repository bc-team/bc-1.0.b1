<?php


	/*
	
	This file is part of beContent.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with beContent.  If not, see <http://www.gnu.org/licenses/>.
    
    http://www.becontent.org
    
    */




/* ///////////////////////////////////// SYSTEM ENTITIES //////////////////////// */

/* GROUPS - It is important to have it in this position */

$groupsEntity = new Entity($database,"groups");
$groupsEntity->setPresentation("name");

$groupsEntity->addField("name", VARCHAR, 50);
$groupsEntity->addField("description", TEXT);

$groupsEntity->connect();

/* ENTITIES - It is important to have it in this position */

$entitiesEntity = new Entity($database, "entities");
$entitiesEntity->setPresentation("name");

$entitiesEntity->addPrimaryKey("name", VARCHAR, 50);
$entitiesEntity->addField("content_name", VARCHAR, 50);
$entitiesEntity->addField("owner", VARCHAR, 1);


$entitiesEntity->addField("forum", VARCHAR, 1);
$entitiesEntity->addReference($groupsEntity, "forum_moderator");

$entitiesEntity->addReference($groupsEntity,"moderator_group");
$entitiesEntity->addReference($groupsEntity,"priviledged_group");

$entitiesEntity->connect();

/* ROLES */

$roleEntity = new Entity($database, "role");
$roleEntity->setPresentation("name_it");

$roleEntity->addField("name_it", VARCHAR, 100);
$roleEntity->addField("name_en", VARCHAR, 100);
$roleEntity->addField("name_pl_it", VARCHAR, 100);
$roleEntity->addField("name_pl_en", VARCHAR, 100);

$roleEntity->addField("position", POSITION);
$roleEntity->addField("active", VARCHAR, 1);

$roleEntity->connect();

/* USERS */

$usersEntity = new Entity($database, "users");
$usersEntity->setPresentation("%name %surname (%username)");
#$usersEntity->setPresentation("name surname (username)");

$usersEntity->addPrimaryKey("username", VARCHAR, 15);
$usersEntity->addField("password", PASSWORD);
$usersEntity->addField("email", VARCHAR, 100);
$usersEntity->addField("name", VARCHAR, 50);
$usersEntity->addField("surname", VARCHAR, 50);
$usersEntity->addField("foto", FILE);
$usersEntity->addReference($roleEntity, "role");
$usersEntity->addField("phone", VARCHAR, 20);
$usersEntity->addField("fax", VARCHAR, 20);
$usersEntity->addField("active", VARCHAR, 1);
$usersEntity->addField("home", VARCHAR, 1);

/* These are necessary for the newsletter management */

$usersEntity->addField("active_newsletter", VARCHAR, 1);
$usersEntity->addField("processed", VARCHAR, 1);

/* additional fields follow here */

$usersEntity->connect();

$usersEntity->setTextSearchFields("name", "surname", "email", "phone");
$usersEntity->setSearchPresentationHead("name", "surname");
$usersEntity->setSearchPresentationBody("email", "phone");
$usersEntity->setHandler("home.php");


/* USER-GROUPS */

$usersGroupsRelation = new Relation($usersEntity, $groupsEntity);

$usersGroupsRelation->connect();

/* SERVICE CATEGORIES */

$servicecategoryEntity = new Entity($database, "servicecategory");
$servicecategoryEntity->setPresentation("name");

$servicecategoryEntity->addField("name", VARCHAR, 40);
$servicecategoryEntity->addField("position", POSITION);

$servicecategoryEntity->connect();



/* SERVICES */

$servicesEntity = new Entity($database,"services");
$servicesEntity->setPresentation("name");

$servicesEntity->addField("name", VARCHAR, 50);
$servicesEntity->addField("script", VARCHAR, 100);
$servicesEntity->addField("entry", VARCHAR, 30);
$servicesEntity->addReference($servicecategoryEntity, "servicecategory");
$servicesEntity->addField("visible", VARCHAR, 1);
$servicesEntity->addField("des", TEXT);
$servicesEntity->addReference($entitiesEntity, "id_entities");
$servicesEntity->addReference($groupsEntity, "superuser_group");
$servicesEntity->addField("position", POSITION);

$servicesEntity->connect();

/* SERVICES-GROUPS */

$servicesGroupsRelation = new Relation($servicesEntity, $groupsEntity);
$servicesGroupsRelation->connect();

/* LOGGING */

$logEntity = new Entity($database, "logs");

$logEntity->setPresentation("date", "entity", "operation");

$logEntity->addField("operation", VARCHAR, 20);
$logEntity->addField("entity", VARCHAR, 100);
$logEntity->addField("itemid", VARCHAR, 255);
$logEntity->addField("service", VARCHAR, 100);
$logEntity->addField("username", VARCHAR, 15);
$logEntity->addField("date", LONGDATE);
$logEntity->addField("ip",VARCHAR, 15);

$logEntity->connect();


/* ///////////////////////////////////// RSS MANAGEMENT //////////////////////// */

/* 

	This entity is preposed for the Rss channels gestion. 
	Is important that all the fields have the correspondent name of 
	the Rss 2.0 TAG. The field title,link and description is MANDATORY.
	
	For the composed Tag (es. <image>) is sufficient have fields 
	for the children Tag (es. <link> ) as parent_cildren (es. image_link)
	Is possible define a n<->n relation only if the name is'n 
	automaticaly generation and don't contain bc_channel that substring
	
	
*/


/* LANGUAGES */

$lanEntity = new Entity($database, "rsslanguages");
$lanEntity->setPresentation("code", "name");

$lanEntity->addPrimaryKey("code", VARCHAR, 8);
$lanEntity->addField("name", VARCHAR, 50);

$lanEntity->connect();

/* CHANNELS */

$channelEntity = new Entity($database,"bc_channel");
$channelEntity->setPresentation("title");

$channelEntity->addField("title",VARCHAR,50,MANDATORY);
$channelEntity->addField("link",VARCHAR,100,MANDATORY);
$channelEntity->addField("description",VARCHAR,150,MANDATORY);
$channelEntity->addReference($lanEntity, "language");

$channelEntity->addField("image_title",VARCHAR,50);
$channelEntity->addField("image_link",VARCHAR,100);
$channelEntity->addField("image",FILE);


$channelEntity->connect();

/*Channel-entity*/

$channelAssotiation = new Entity($database,"channel_entity");
$channelAssotiation->setPresentation("entity");
$channelAssotiation->addField("entity",VARCHAR,50,MANDATORY);
$channelAssotiation->addReference($channelEntity);

$channelAssotiation->connect();

$rssMod=new Entity($database,"bc_rss_mod");
$rssMod->setPresentation("entity");
$rssMod->addPrimaryKey("entity",VARCHAR,50);
$rssMod->addField("modality",VARCHAR,20,MANDATORY);


$rssMod->connect();

/* ////////////////////////////// COMMENTS ////////////////////////// */

$commentEntity = new Entity($database, "comments", WITH_OWNER);
$commentEntity->setPresentation("entityname", "itemid");

$commentEntity->addField("entityname", VARCHAR, 100);
$commentEntity->addField("itemid", VARCHAR, 255);
$commentEntity->addField("body", TEXT);
$commentEntity->addField("rate", VARCHAR, 1);
$commentEntity->addField("ratenumbers", INT);
$commentEntity->addField("active", VARCHAR, 1);
$commentEntity->addField("new", VARCHAR, 1);

$commentEntity->connect();

/* ////////////////////////////////////////////////////////////////// */


/* SECTIONS */

$sectionEntity = new Entity($database, "section");
$sectionEntity->setPresentation("name");

$sectionEntity->addField("name", VARCHAR, 40);

$sectionEntity->connect();

/* PAGE CONTENTS - OK*/


$pageEntity = new Entity($database, "page", WITH_OWNER);
$pageEntity->setPresentation("title_it");

$pageEntity->addReference($sectionEntity, "section");
$pageEntity->addField("title_it", VARCHAR, 100); 
$pageEntity->addField("title_en", VARCHAR, 100); 
$pageEntity->addField("subtitle_it", VARCHAR, 100); 
$pageEntity->addField("subtitle_en", VARCHAR, 100); 
$pageEntity->addField("body_it", TEXT);
$pageEntity->addField("body_en", TEXT);
$pageEntity->addField("foto", FILE);
$pageEntity->addField("position", POSITION);
$pageEntity->addField("link", VARCHAR, 100);

$pageEntity->connect();

$pageEntity->setTextSearchFields("title_it",  "title_en", "body_it", "body_en");
$pageEntity->setSearchPresentationHead("title");
$pageEntity->setSearchPresentationBody("body");
$pageEntity->setHandler("page.php");

/* MENU - OK*/

$menuEntity = new Entity($database, "menu");
$menuEntity->setPresentation("entry_it");

$menuEntity->addField("entry_it", VARCHAR, 50); 
$menuEntity->addField("entry_en", VARCHAR, 50); 
$menuEntity->addField("link", VARCHAR, 255);
$menuEntity->addReference($pageEntity, "page_id");
$menuEntity->addReference($menuEntity, "parent_id");
$menuEntity->addField("position", POSITION);

$menuEntity->connect();

/* NEWS */

$newsEntity = new Entity($database, "news", WITH_OWNER);
$newsEntity->setPresentation("title_it");

$newsEntity->addField("title_it", VARCHAR, 68, MANDATORY);
$newsEntity->addField("title_en", VARCHAR, 68, MANDATORY);

$newsEntity->addField("date", LONGDATE, MANDATORY);
$newsEntity->addField("active", VARCHAR, 1);
$newsEntity->addField("body_it", TEXT); ;
$newsEntity->addField("body_en", TEXT); ;

$newsEntity->addRss($channelEntity,"title=\"title_it\" description=\"body_it\" pubDate=\"date\"");
#$newsEntity->addRssFilter("active = '*'");

$newsEntity->connect();

$newsEntity->setTextSearchFields("title_it", "title_en", "body_it", "body_en");
$newsEntity->setSearchPresentationHead("title");
$newsEntity->setSearchPresentationBody("body");
$newsEntity->setHandler("news.php");

/* EVENTS */

$eventEntity = new Entity($database, "event", WITH_OWNER);
$eventEntity->setPresentation("acronym");

$eventEntity->addField("acronym", VARCHAR, 20);
$eventEntity->addField("name", VARCHAR, 100);
$eventEntity->addField("venue", VARCHAR, 40);
$eventEntity->addField("country", VARCHAR, 40);
$eventEntity->addField("body", TEXT);
$eventEntity->addField("link", VARCHAR, 100);
$eventEntity->addField("date_begin", DATE);
$eventEntity->addField("date_end", DATE);

$eventEntity->addRss($channelEntity,"title=\"name\" description=\"body\" pubDate=\"date_begin\"");

$eventEntity->connect();

$eventEntity->setTextSearchFields("acronym", "name", "body");
$eventEntity->setSearchPresentationHead("acronym", "name");
$eventEntity->setSearchPresentationBody("body");
$eventEntity->setHandler("event.php");


/* HOMEPAGE */

$homeEntity = new Entity($database, "homepage", WITH_OWNER);
$homeEntity->setPresentation("title_it");

$homeEntity->addField("title_it", VARCHAR, 100);
$homeEntity->addField("title_en", VARCHAR, 100);
$homeEntity->addField("entry_it", VARCHAR, 20);
$homeEntity->addField("entry_en", VARCHAR, 20);
$homeEntity->addField("body_it", TEXT);
$homeEntity->addField("body_en", TEXT);
$homeEntity->addField("active", VARCHAR, 1);
$homeEntity->addField("position", POSITION);

$homeEntity->connect();

/* PUB TYPES */

$pubtypeEntity = new Entity($database, "pubtype");
$pubtypeEntity->setPresentation("name_it");

$pubtypeEntity->addField("name_it", VARCHAR, 30);
$pubtypeEntity->addField("name_en", VARCHAR, 30);
$pubtypeEntity->addField("position", POSITION);

$pubtypeEntity->connect();

/* PUBLICATIONS */

$pubEntity = new Entity($database, "publication", WITH_OWNER);
$pubEntity->setPresentation("title");

$pubEntity->addField("title", VARCHAR, 255);
$pubEntity->addField("authors", VARCHAR, 255);
$pubEntity->addField("abstract", TEXT);
$pubEntity->addField("year", VARCHAR, 4);
$pubEntity->addField("venue", TEXT);
$pubEntity->addReference($pubtypeEntity, "type");
$pubEntity->addField("pdf", FILE);

$pubEntity->connect();

$pubEntity->setTextSearchFields("title", "authors", "abstract");
$pubEntity->setSearchPresentationHead("title");
$pubEntity->setSearchPresentationBody("authors", "abstract");
$pubEntity->setHandler("pub.php");

/* REL PUBLICATIONS - USERS */

$pubAuthors = new Relation($pubEntity, $usersEntity);
$pubAuthors->connect();

/* SEMINARI */

$talkEntity = new Entity($database, "talk", WITH_OWNER);
$talkEntity->setPresentation("author", "title");

$talkEntity->addField("title", VARCHAR, 100);
$talkEntity->addField("author", VARCHAR, 100);
$talkEntity->addField("website", VARCHAR, 100);
$talkEntity->addField("affiliation", TEXT);
$talkEntity->addField("abstract", TEXT);
$talkEntity->addField("date", LONGDATE);
$talkEntity->addField("venue", VARCHAR, 500);

$talkEntity->connect();

$talkEntity->setTextSearchFields("title", "author", "abstract");
$talkEntity->setSearchPresentationHead("title");
$talkEntity->setSearchPresentationBody("authors", "abstract");
$talkEntity->setHandler("talk.php");

/* DOCTYPE */

$doctypeEntity = new Entity($database, "doctype");
$doctypeEntity->setPresentation("name_it");

$doctypeEntity->addField("name_it", VARCHAR, 40);
$doctypeEntity->addField("name_en", VARCHAR, 40);
$doctypeEntity->addField("body_it", TEXT);
$doctypeEntity->addField("body_en", TEXT);
$doctypeEntity->addField("position", POSITION);
$doctypeEntity->addReference($doctypeEntity, "parent_id");

$doctypeEntity->connect();

/* DOC */

$docEntity = new Entity($database, "doc", WITH_OWNER);
$docEntity->setPresentation("name_it");

$docEntity->addField("name_it", VARCHAR, 100);
$docEntity->addField("name_en", VARCHAR, 100);
$docEntity->addField("document", FILE);
$docEntity->addReference($doctypeEntity, "category");
$docEntity->addField("body_it", TEXT);
$docEntity->addField("body_en", TEXT);
$docEntity->addField("public", VARCHAR, 1);
$docEntity->addField("position", POSITION);

$docEntity->connect();


/* FAQTYPE */

$faqtypeEntity = new Entity($database, "faqtype");
$faqtypeEntity->setPresentation("name_it");

$faqtypeEntity->addField("name_it", VARCHAR, 40);
$faqtypeEntity->addField("name_en", VARCHAR, 40);
$faqtypeEntity->addField("body_it", TEXT);
$faqtypeEntity->addField("body_en", TEXT);
$faqtypeEntity->addField("position", POSITION);
$faqtypeEntity->addReference($faqtypeEntity, "parent_id");

$faqtypeEntity->connect();



/* FAQ */

$faqEntity = new Entity($database, "faq", WITH_OWNER);
$faqEntity->setPresentation("question_it");

$faqEntity->addField("question_it", VARCHAR, 100);
$faqEntity->addField("question_en", VARCHAR, 100);

$faqEntity->addReference($faqtypeEntity, "category");
$faqEntity->addField("answer_it", TEXT);
$faqEntity->addField("answer_en", TEXT);
$faqEntity->addField("public", VARCHAR, 1);
$faqEntity->addField("position", POSITION);

$faqEntity->connect();

$faqEntity->setTextSearchFields("question_it", "question_en", "answer_it", "answer_en");
$faqEntity->setSearchPresentationHead("question");
$faqEntity->setSearchPresentationBody("answer");
$faqEntity->setHandler("faq.php");

/* JOB */

$jobEntity = new Entity($database, "job", WITH_OWNER);
$jobEntity->setPresentation("title_it");

$jobEntity->addField("title_it", VARCHAR, 100);
$jobEntity->addField("title_en", VARCHAR, 100);

$jobEntity->addField("body_it", TEXT);
$jobEntity->addField("body_en", TEXT);

$jobEntity->addReference($usersEntity, "reference");

$jobEntity->addField("active", VARCHAR, 1);

$jobEntity->addRss($channelEntity,"title=\"title_it\" description=\"body_it\" pubDate=\"creation\"");
#$newsEntity->addRssFilter("active = '*'");

$jobEntity->connect();

/* PROJECT TYPE */

$pType = new Entity($database, "projecttype");
$pType->setPresentation("name");


$pType->addField("name", VARCHAR, 50);
$pType->addField("position", POSITION);

$pType->connect();

/* PROJECT */

$projectEntity = new Entity($database, "project", WITH_OWNER);
$projectEntity->setPresentation("%name - %acronym");

$projectEntity->addField("name", VARCHAR, 100);
$projectEntity->addField("acronym", VARCHAR, 20);
$projectEntity->addReference($pType, "type");
$projectEntity->addField("date_begin", DATE);
$projectEntity->addField("date_end", DATE);
$projectEntity->addField("des", TEXT);
$projectEntity->addField("link", VARCHAR, 100);
$projectEntity->addField("logo", FILE);

$projectEntity->connect();

/* REL PROJECT-USERS */

$pUsers = new Relation($projectEntity, $usersEntity);
$pUsers->connect();

?>