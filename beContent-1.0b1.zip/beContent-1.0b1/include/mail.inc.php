<?php

Class Mail {
	var
	$to,
	$from,
	$subject,
	$message,

	$file,
	$file_type,
	$file_name,

	$buffer,
	$buffer_type,
	$buffer_name;

	function Mail() {

	}

	
	
	function addFrom($from) {
		$this->from = $from;
	}

	function addTo($to) {
		$this->to = $to;
	}

	function addSubject($subject) {
		$this->subject = $subject;
	}

	function addMessage($message) {
		$this->message = $message;
	}

	function addAttachment($file, $name, $type) {

		$this->file[] = $file;
		$this->file_name[] = $name;
		$this->file_type[] = $type;
	}

	function addAttachmentFromString($buffer, $name, $type) {
		$this->buffer[] = $buffer;
		$this->buffer_name[] = $name;
		$this->buffer_type[] = $type;
	}

	function send() {



		$uid = strtoupper(md5(uniqid(time())));

		$header = "From: ".$this->from."\nReply-To: ".$this->from."\n";
		$header .= "MIME-Version: 1.0\n";
		$header .= "Content-Type: multipart/mixed; boundary=$uid\n";
		$header .= "--$uid\n";
		$header .= "Content-Type: text/plain\n";
		$header .= "Content-Transfer-Encoding: 8bit\n\n";
		$header .= $this->message."\n";

		if (is_array($this->file)) {
			foreach($this->file as $k => $v) {

				$content = fread(fopen($this->file[$k],"r"),filesize($this->file[$k]));
				$content = chunk_split(base64_encode($content));

				$header .="--$uid\n";
				$header .= "Content-Type: ".$this->file_type[$k]."; name=\"".$this->file_name[$k]."\"\n";
				$header .= "Content-Transfer-Encoding: base64\n";
				$header .= "Content-Disposition: attachment; filename=\"".$this->file_name[$k]."\"\n\n";
				$header .= "$content\n";
			}
		}

		if (is_array($this->buffer)) {
			foreach($this->buffer as $k => $v) {

				$content = chunk_split(base64_encode($v));

				$header .="--$uid\n";
				$header .= "Content-Type: ".$this->buffer_type[$k]."; name=\"".$this->buffer_name[$k]."\"\n";
				$header .= "Content-Transfer-Encoding: base64\n";
				$header .= "Content-Disposition: attachment; filename=\"".$this->buffer_name[$k]."\"\n\n";
				$header .= "$content\n";

			}
		}


		mail($this->to, $this->subject, "", $header);
		return true;


	}
}

?>