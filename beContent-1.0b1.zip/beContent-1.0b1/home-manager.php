<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";
require "include/content.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$homeEntity);

$form->addSection("Homepage Management");

$form->addText("title_it", "Title (it)", 60, MANDATORY);
$form->addText("title_en", "Title (en)", 60, MANDATORY);

if (($_SESSION['user']['admin']) or (Auth::isSuperuser())) {
	$form->addSelectFromReference2($usersEntity, "username", "User", MANDATORY);	
}

$form->addText("entry_it", "Menu Entry(it)", 60, MANDATORY);
$form->addText("entry_en", "Menu Entry(en)", 60, MANDATORY);
$form->addEditor("body_it", "Content (it)", 30, 120);
$form->addEditor("body_en", "Content (en)", 30, 120);

$form->addCheck("Active", ":active:*:CHECKED");

if (($_SESSION['user']['admin']) or (Auth::isSuperuser())) {
	$form->addHierarchicalPosition("position", "Position", "title_it", "username");
} else {
	$form->addPosition("position", "Position", "title_it");
}

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}

$main->close();

?>