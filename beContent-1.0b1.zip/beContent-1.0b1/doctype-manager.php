<?php

session_start();

require "include/template2.inc.php";
require "include/beContent.inc.php";

require "include/auth.inc.php";

$main = new Skin(); 

$form = new Form("dataEntry",$doctypeEntity);

$form->addSection("Document Type Management");

$form->addText("name_it", "Name (it)", 40, MANDATORY);
$form->addText("name_en", "Name (en)", 40, MANDATORY);
$form->addEditor("body_it", "Body (it)", 7, 70);
$form->addEditor("body_en", "Body (en)", 7, 70);
$form->addSelectFromReference2($doctypeEntity, "parent_id", "Parent");
$form->addHierarchicalPosition("position", "Position", "name_it", "parent_id");

if (!isset($_REQUEST['action'])) {
	$_REQUEST['action'] = "edit";
}
switch($_REQUEST['action']) {
	case "add":
	$main->setContent("body",$form->addItem());
	break;
	case "edit":
	$main->setContent("body",$form->editItem());
	break;
}


$main->close();

?> 